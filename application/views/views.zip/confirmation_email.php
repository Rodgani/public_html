<html>
	<head>
		<title>Bestätigungs-E-Mail von automobile-wohlensee.ch</title>
	</head>
	<body>
		<h1>Bestätigungs-E-Mail von automobile-wohlensee.ch</h1>
		<p>Vielen Dank, dass Sie sich für die automobile-wohlensee.ch entschieden haben. Wir haben Ihre Anfrage für das Fahrzeug erhalten. Unser Teamvertreter wird Sie so schnell wie möglich per E-Mail oder Handy kontaktieren</p>

	</body>
</html>