<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional //EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:v="urn:schemas-microsoft-com:vml">
<head>
<!--[if gte mso 9]><xml><o:OfficeDocumentSettings><o:AllowPNG/><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml><![endif]-->
<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
<meta content="width=device-width" name="viewport"/>
<!--[if !mso]><!-->
<meta content="IE=edge" http-equiv="X-UA-Compatible"/>
<!--<![endif]-->
<title></title>
<!--[if !mso]><!-->
<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css"/>
<!--<![endif]-->
<style type="text/css">
		body {
			margin: 0;
			padding: 0;
		}

		table,
		td,
		tr {
			vertical-align: top;
			border-collapse: collapse;
		}

		* {
			line-height: inherit;
		}

		a[x-apple-data-detectors=true] {
			color: inherit !important;
			text-decoration: none !important;
		}
	</style>
<style id="media-query" type="text/css">
		@media (max-width: 640px) {

			.block-grid,
			.col {
				min-width: 320px !important;
				max-width: 100% !important;
				display: block !important;
			}

			.block-grid {
				width: 100% !important;
			}

			.col {
				width: 100% !important;
			}

			.col>div {
				margin: 0 auto;
			}

			img.fullwidth,
			img.fullwidthOnMobile {
				max-width: 100% !important;
			}

			.no-stack .col {
				min-width: 0 !important;
				display: table-cell !important;
			}

			.no-stack.two-up .col {
				width: 50% !important;
			}

			.no-stack .col.num4 {
				width: 33% !important;
			}

			.no-stack .col.num8 {
				width: 66% !important;
			}

			.no-stack .col.num4 {
				width: 33% !important;
			}

			.no-stack .col.num3 {
				width: 25% !important;
			}

			.no-stack .col.num6 {
				width: 50% !important;
			}

			.no-stack .col.num9 {
				width: 75% !important;
			}

			.video-block {
				max-width: none !important;
			}

			.mobile_hide {
				min-height: 0px;
				max-height: 0px;
				max-width: 0px;
				display: none;
				overflow: hidden;
				font-size: 0px;
			}

			.desktop_hide {
				display: block !important;
				max-height: none !important;
			}
		}
	</style>
</head>
<body class="clean-body" style="margin: 0; padding: 0; -webkit-text-size-adjust: 100%; background-color: #FFFFFF;">
<!--[if IE]><div class="ie-browser"><![endif]-->
<table bgcolor="#FFFFFF" cellpadding="0" cellspacing="0" style=" min-width: 320px; Margin: 0 auto; border-spacing: 0; border-collapse: collapse; mso-table-lspace: 0pt; mso-table-rspace: 0pt; background-color: #FFFFFF; width: 100%;" valign="top" width="100%">
<tbody>


<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> automarke </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['automarke']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> modell </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['modell']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> aufbau </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['aufbau']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> farbe </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['farbe']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> inverkehrssetzung </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['inverkehrssetzung']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> kilometerstand </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['kilometerstand']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> treibstoff </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['treibstoff']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> getriebeart </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['getriebeart']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> typenschein </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['typenschein']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> fahrzeugzustand </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['fahrzeugzustand']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> name </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['name']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> vorname </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['vorname']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> Adresse </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['Adresse']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> plz_ort </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['plz_ort']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> email </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['email']  ?> </td>
</tr>
<tr style="vertical-align: top;" valign="top">
<td style="word-break: break-word; vertical-align: top;" valign="top"> telefon </td>
<td style="word-break: break-word; vertical-align: top;" valign="top"> <?php echo $_POST['telefon']  ?> </td>
</tr>
</tbody>
</table>
<!--[if (IE)]></div><![endif]-->
</body>
</html>