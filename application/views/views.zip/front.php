<?php  include 'front_template/header_front.php'; ?>
<?php  include 'front_template/navigation_front.php'; ?>
<?php include 'front/'.$page_name.'.php'; ?>
<?php include 'front_template/footer_front.php'; ?>