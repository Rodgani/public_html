<style>body{ background-color: #fff !important; }</style>

    <section id="main">
      <div class="container">
        <div class="row">
          <div class="col">
                <iframe id="iFrame1" height="3900px" width="100%" name="htmlComp-iframe" scrolling="auto" src="https://www-automobile-wohlensee-ch.filesusr.com/html/f754b9_44ce487e01aaf62cc57a752563f9c28f.html"></iframe>
          </div>
        </div>
      </div>
    </section>