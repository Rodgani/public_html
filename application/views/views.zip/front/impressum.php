<style>
  .line-zero-2{
    line-height: 0.2  !important;
  }
    .heading_2{
      font-size:22px;line-height:1.9;color:#8e8c8b ;
    }
</style>
    <section id="main">
      <div class="container">

            <div class="row pt-5 pb-4 px-5 bg-white mb-5 font-weight-light custom-pera">
            <div class="col-md-7 pt-5">
            <h3 class="left-br">Impressum <br> <span style="font-weight: 100;"> Copyright</span></h3><br>
            <p>Das Co­py­right für sämt­li­che In­hal­te die­ser Web­site liegt bei:</p>
            <h4 class="heading_2">Automobile Wohlensee AG</h4>
<p class="line-zero-2 mt-4">Heidmoosweg 15</p>
<p class="line-zero-2">3049 Säriswil</p>
<br><br>
<p class="line-zero-2">Telefon: 031 503 10 12</p>
<p class="line-zero-2">Natel: 079 942 58 61</p>
<p class="line-zero-2">E-Mail: info@automobile-wohlensee.ch</p>

<h4 class="heading_2 my-3">Vertreten durch:</h4>
<p class="line-zero-2">Ismail  Ismajli</p>
<p class="line-zero-2">Eingetragen in Bern</p>

<h4 class="heading_2 mt-2 mb-2">Dislaimer:</h4>
<p>Alle Texte und Links wur­den sorg­fäl­tig ge­prüft und wer­den lau­fend ak­tua­li­siert. Wir sind be­müht, rich­ti­ge und voll­stän­di­ge In­for­ma­tio­nen auf die­ser Web­site be­reit­zu­stel­len, über­neh­men aber kei­ner­lei Ver­ant­wor­tung, Ga­ran­ti­en oder Haf­tung dafür, dass die durch diese Web­site be­reit­ge­stell­ten In­for­ma­tio­nen, rich­tig, voll­stän­dig oder ak­tu­ell sind. Wir be­hal­ten uns das Recht vor, je­der­zeit und ohne Vor­an­kün­di­gung die In­for­ma­tio­nen auf die­ser Web­site zu än­dern und ver­pflich­ten uns auch nicht, die ent­hal­te­nen In­for­ma­tio­nen zu ak­tua­li­sie­ren. Alle Links zu ex­ter­nen An­bie­tern wur­den zum Zeit­punkt ihrer Auf­nah­me auf ihre Rich­tig­keit über­prüft, den­noch haf­ten wir nicht für In­hal­te und Ver­füg­bar­keit von Web­sites, die mit­tels Hy­per­links zu er­rei­chen sind. Für il­le­ga­le, feh­ler­haf­te oder un­voll­stän­di­ge In­hal­te und ins­be­son­de­re für Schä­den, die durch In­hal­te ver­knüpf­ter Sei­ten ent­ste­hen, haf­tet al­lein der An­bie­ter der Seite, auf wel­che ver­wie­sen wurde. Dabei ist es gleich­gül­tig, ob der Scha­den di­rek­ter, in­di­rek­ter oder fi­nan­zi­el­ler Natur ist oder ein sons­ti­ger Scha­den vor­liegt, der sich aus Da­ten­ver­lust, Nut­zungs­aus­fall oder an­de­ren Grün­den aller Art er­ge­ben könn­te.</p>












            </div>
            <div class="col-md-5 pt-5 ">
            <h3 class="left-br ">Hinweise zur <br>Webseite</h3><br>
            <p class="line-zero-2">​Webentwicklung und Umsetzung</p>
            <br>
            <p class="line-zero-2" style="color: #a85454">ArCa-IT AG</p>
            <p class="line-zero-2">Heidmoosweg 15</p>
            <p class="line-zero-2">3049 Säriswil</p>

            <p class="line-zero-2">Telefon: 031 89 80 80</p>
            <p class="line-zero-2">E-Mail: info@arca-it.ch</p>
            <p class="line-zero-2">Website: www.arca-it.ch</p>
            </div>
            

           

            
              
            </div>
      </div>
    </section>