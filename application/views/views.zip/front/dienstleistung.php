   <style>
   	.number_heading{
   		font-size: 55px;
   		color: #3B3C95;

   	}
   	.heading_2{
   		font-size:22px;line-height:1.9;color:#000;
   	}
    .custom-pera p {
      line-height: 1.5;
    }
    .bordered_col{
      border-bottom: 1px dotted #8E8C8B; 
    }
    .fa-check{
      font-size: 25px;
      color: #8E8C8B;
    }
   </style> 
    <section id="main">
      <div class="container">

        	<div class="row pt-5 pb-4 px-5 bg-white mb-5 font-weight-light custom-pera">
            <div class="col-md-12 pt-5 pl-5">
            <h3 class="left-br font-weight-light">Dienstleistung</h3>
            <strong><p class="ml-3 mt-5">Die wichtigsten Gründe, warum Sie profitieren, wenn Sie ihr nächstes Fahrzeug bei uns erwerben:
​</p></strong>
            </div>

            <div class="row ">
              <div class="col-md-1 p-4 mt-2"><i class="fa fa-check"></i> </div>
              <div class="col-md-11 p-4  bordered_col w-100 custom-pera">
                 <p class="m-0 p-0">
Qualität ist unser Markenzeichen. Nach dem Kauf, stehen wir Ihnen zu sehr fairen Konditionen jeglicher Reparaturen zur Verfügung. </p>
              </div>
            </div>


            <div class="row ">
              <div class="col-md-1 p-4 mt-2"><i class="fa fa-check"></i> </div>
              <div class="col-md-11 p-4  bordered_col w-100 custom-pera">
                 <p class="m-0 p-0">Bei uns werden Sie freundlich und kompetent beraten, Sie können unsere Fahrzeuge entspannt und ohne Aufdringlichkeit besichtigen. </p>
              </div>
            </div>



             <div class="row ">
              <div class="col-md-1 p-4 mt-2"><i class="fa fa-check"></i> </div>
              <div class="col-md-11 p-4  bordered_col w-100 custom-pera">
                 <p class="m-0 p-0">Unserer Firmenphilosophie entsprechend legen wir grossen Wert auf Kundenzufriedenheit und Transparenz. Da wir nichts zu verbergen haben, darf jeder Kunde vor der Kaufentscheidung mit seinem Wunschfahrzeug in die Werkstatt seines Vertrauens oder zu einer Prüforganisation seiner Wahl fahren, um sich den Fahrzeugzustand von unabhängiger Seite bestätigen zu lassen. </p>
              </div>
            </div>


             <div class="row ">
              <div class="col-md-1 p-4 mt-2"><i class="fa fa-check"></i> </div>
              <div class="col-md-11 p-4  bordered_col w-100 custom-pera">
                 <p class="m-0 p-0">Wir garantieren die Kilometerstände unserer Fahrzeuge. Zudem bieten wir Ihnen gerne eine maßgeschneiderte Finanzierung, auch ohne Anzahlung. </p>
              </div>
            </div>

            <div class="row ">
              <div class="col-md-1 p-4 mt-2"><i class="fa fa-check"></i> </div>
              <div class="col-md-11 p-4  bordered_col w-100 custom-pera">
                 <p class="m-0 p-0">Auf Wunsch &uuml;bernehmen wir gern die Zulassungsformalit&auml;ten. sdfgsdfgsfdgsfdgsfdgd sg sfdg sdfg sdfg sdfg </p>
              </div>
            </div>  


             <div class="row ">
              <div class="col-md-1 p-4 mt-2"><i class="fa fa-check"></i> </div>
              <div class="col-md-11 p-4  bordered_col w-100 custom-pera">
                 <p class="m-0 p-0">Ihren bisherigen Wagen nehmen wir gern in Zahlung, wir kaufen Ihr Auto aber auch, ohne dass Sie ein neues Auto bei uns kaufen müssen, auch mit Ablösung einer eventuell vorhandenen Finanzierung.</p>
              </div>
            </div>


             <div class="row ">
              <div class="col-md-1 p-4 mt-2"><i class="fa fa-check"></i> </div>
              <div class="col-md-11 p-4  custom-pera">
                 <p class="m-0 p-0">Die Qualitätsoccassionen versuchen wir so schnell wie möglich ablieferbereit zu stellen. Jedes verkaufte Auto wird mit Aufbereitung Volltank und der aktuellen Vignette abgeliefert. </p>
              </div>
            </div>



        		
              
            </div>

        	</div>
        </div>
    </div>
  </div>
</section>