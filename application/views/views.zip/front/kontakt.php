
    <section id="main">
      <div class="container">
        <div class="row pt-5 pb-4 px-5 bg-white mb-5 font-weight-light custom-pera">
          <div class="col">
            <br><br><br>
            <div class="row">
              <div class="col-md-6  custom-pera pl-4">
                <h2 class="font-weight-light contact_heading">Standort</h2>
<p class="m-0 pt-4 p line-height-1">Automobile Wohlensee AG <br>  
Heidmoosweg 15 <br>
3049 Säriswil</p>
<p class="m-0 p-0 line-height-1">T: +41 (0)31 503 10 12   <br> 
M: info@automobile-wohlensee.ch</p>
              </div>
              <div class="col-md-6 custom-pera pl-4">
                

                <h2 class="font-weight-light contact_heading">Öffnungszeiten</h2>
<p class="m-0 p-0 line-height-1"  > Montag - Freitag <br>
09:00 Uhr - 12:00 Uhr <br>
13:00 Uhr - 20:00 Uhr </p>
<p class="m-0 p-0 line-height-1">Samstag <br>
09:00 Uhr - 17:00 Uhr</p>
<p class="m-0 p-0 line-height-1">Sonntag <br>
geschlossen</p>
              </div>
            </div>

            <div class="row mt-4 mb-2">
              <div class="col-md-12">
                <div style="width: 100%"><iframe width="100%" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=Automobile%20Wohlensee%20AG+(Automobile%20Wohlensee%20AG)&amp;t=p&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>