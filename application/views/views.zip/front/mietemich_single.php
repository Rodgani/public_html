<style>body{ background-color: #fff !important; }</style>

    <section id="main">
      <div class="main-bg"></div>
      <div class="container py-5">
        <div class="row">
          <input type="hidden" id="selected_vehicle" value="<?php echo $mietemich[0]['id']; ?>">
          
          <div class="col-lg-4 col-md-4 pr-4">

            <h5 class="text-primary font-weight-normal mb-0">Fahrzeuge</h5>
            <h4 style="text-transform: capitalize;" class="font-weight-bold mb-0"><?php echo $mietemich[0]['vehicle_brand']; ?></h4>
            <h1 style="text-transform: capitalize;" class="font-weight-bold mb-1"><?php echo $mietemich[0]['vehicle_name']; ?></h1>
            </div>
            <div class="col-md-6">
              <!-- Swiper -->
              <div class="swiper-container gallery-top">
                <div class="swiper-wrapper">
                  <?php $images = explode(',', $mietemich[0]['images']); ?>
                  <?php foreach ($images as $key => $image): ?>
                    
                  <div class="swiper-slide" style="background-image:url(../uploads/mietemich/<?php echo $image ?>)"></div>
                  <?php endforeach ?>
                  
                </div>
                <!-- Add Arrows -->
                <div class="swiper-button-next swiper-button-white"></div>
                <div class="swiper-button-prev swiper-button-white"></div>
              </div>
            </div>
            <div class="col-md-2"></div>
          <div class="col-md-6">
              <div class="swiper-container gallery-thumbs">
                <div class="swiper-wrapper">
                   <?php foreach ($images as $key => $image): ?>
                  <div class="swiper-slide" style="background-image:url(../uploads/mietemich/<?php echo $image ?>)"></div>
                   <?php endforeach ?>
                 
                  
                </div>
              </div>
             
            <div class="clearfix py-2"></div> 

          </div>
           <div class="col-md-6"></div>
          
          <div class="col-lg-6 col-md-4">

            <div class="card shadow-sm border-0">
              <div class="card-body">
                <h4 class="mb-3">Konfiguriere dein Abo</h4>
                <div class="row">
                  <div class="col-md-12 pb-3">
                    <fieldset>
                            <input type="hidden" value="<?php echo $km ?>" id="selected_km_value">
                      <legend class="small mb-0 text-muted">Kilometer pro Monat:</legend>
                        <div class="dropdown">
                          <button id="dLabel" class="dropdown-select selected_km" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo $km; ?>
                            <span class="caret"></span>
                          </button>
                          <input type="hidden" name="kpm">
                          <ul  class="dropdown-menu" aria-labelledby="dLabel" id="km">
                            <li id="100km"> 
                              <span class="lg text float-left">100 km</span>  
                              <div class="clearfix"></div>
                            </li>
                            <li id="200km"> 
                              <span class="lg text float-left">200 km</span>  
                              <div class="clearfix"></div>  
                            </li>
                            <li id="300km"> 
                              <span class="lg text float-left">300 km</span>  
                              <div class="clearfix"></div>
                            </li>
                            <li id="400km">
                              <span class="lg text float-left">400 km</span>  
                              <div class="clearfix"></div>
                            </li>
                            <li id="500km">
                              <span class="lg text float-left">500 km</span>  
                              <div class="clearfix"></div>
                            </li>


                          </ul>
                        </div>
                    </fieldset>
<?php /* ?>
                    <a href="" class="small"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> Mehr Infos zu gefahrenen Kilometern</a>
<?php */ ?>
                  </div>
                  <div class="col-md-12 pb-3">

                    <fieldset>
                            <input type="hidden" value="<?php echo $duration ?>" id="selected_duration_value">
                      <legend class="small mb-0 text-muted">Mindestlaufzeit:</legend>
                        <div class="dropdown">
                          <button id="dLabel" class="dropdown-select selected_duration" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                           <?php echo str_replace('h', ' Stunden', $duration); ?>
                            <span class="caret"></span>
                          </button>
                          <input type="hidden" name="mf">
                          <ul class="dropdown-menu" aria-labelledby="dLabel" id="duration">
                            <li id="3hour"> 
                              <span class="lg text float-left">3 Stunden</span>  
                              <div class="clearfix"></div>
                            </li>
                            <li id="6hour"> 
                              <span class="lg text float-left">6 Stunden</span>  
                              <div class="clearfix"></div>
                            </li>
                            <li id="9hour"> 
                              <span class="lg text float-left">9 Stunden</span>  
                              <div class="clearfix"></div>
                            </li>
                            <li id="12hour"> 
                              <span class="lg text float-left">12 Stunden</span>  
                              <div class="clearfix"></div>
                            </li>
                            <li id="24hour"> 
                              <span class="lg text float-left">24 Stunden</span>  
                              <div class="clearfix"></div>
                            </li>
                            <li id="48hour"> 
                              <span class="lg text float-left">48 Stunden</span>  
                              <div class="clearfix"></div>
                            </li>

                           

                          </ul>
                        </div>
                    </fieldset> 
<?php /* ?>
                    <span class="small"><i class="fa fa-check text-success" aria-hidden="true"></i> Im Anschluss monatlich kündbar</span>
                    <?php */ ?>

                  </div>
                </div>
        
                
                <div class="card violet-blue-bg mt-3 mb-2 px-4 py-0 m-x-40">
                  <div class="card-body">

                    <div class="row">
                      <div class="col-md-6 text-white">
                        <h6 class="mb-0">Tägliches Abonnement</h6>
                        <h3 id="total_price"><strong><?php echo $mietemich[0][$select_price]; ?> CHF</strong></h3>
                      </div>
                      <div class="col-md-6 text-right">
                        
                        <a class="btn btn-success text-white rounded" id="send_request">Jetzt abonnieren</a>

                      </div>
                    </div>
                    
                  </div>
                </div>

              </div>
            </div>
          </div>
           <div class="col-md-1"></div>
           <div class="col-md-5">
             <h4 class="font-weight-bold my-4">Eckdaten</h4>
            
            <ul class="list-group">
              
              <li class="list-group-item border-left-0 border-right-0 px-0 py-2 rounded-0">
                <b>Kategorie</b>
                <span class="float-right vehcile_value"><?php echo $mietemich[0]['vehicle_category'] ?></span>
                <div class="clearfix"></div>
              </li>
              <li class="list-group-item border-left-0 border-right-0 px-0 py-2">
                <b>Motor</b>
                <span class="float-right vehcile_value"><?php echo $mietemich[0]['vehicle_engine']; ?></span>
                <div class="clearfix"></div>
              </li>
              <li class="list-group-item border-left-0 border-right-0 px-0 py-2">
                <b>Getriebe</b>
                <span class="float-right vehcile_value"><?php echo $mietemich[0]['transmision_type']; ?></span>
                <div class="clearfix"></div>
              </li>
              <li class="list-group-item border-left-0 border-right-0 px-0 py-2">
                <b>Antrieb</b>
                <span class="float-right vehcile_value"><?php echo $mietemich[0]['vehicle_drive_type']; ?></span>
                <div class="clearfix"></div>
              </li>


              <li class="list-group-item border-left-0 border-right-0 px-0 rounded-0">
                <b>Treibstoff</b>
                <span class="float-right vehcile_value"><?php echo $mietemich[0]['vehicle_fuel_type']; ?></span>
                <div class="clearfix"></div>
              </li>
            
            </ul> 

            <h4 class="font-weight-bold my-4">Beschreibung</h4>
            <p><?php echo $mietemich[0]['vehicle_description'] ?>.</p> 
        </div>




          <div class="col-md-12">
            
               
            <div class="accordion" id="accordionExample">
              <div class="card border-top-0 border-left-0 border-right-0 border-bottom rounded-0">
                <div class="card-header p-0 bg-white" id="headingOne">
                  <h2 class="mb-0">
                    <button class="btn btn-link pl-0 w-100 text-left text-primary left-big-arrow" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne"><h4 class="mb-1"> &nbsp;Ausstattung </h4></button>
                  </h2>
                </div>

                <div id="collapseOne" class="collapse active" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div class="card-body p-4 bg-grey ">
                   <?php 

                   $numOfCols = 4;
$rowCount = 0;
$bootstrapColWidth = 12 / $numOfCols;
?>
<div class="row">
<?php
foreach ($features as $row){
?>  
        <div class="col-md-<?php echo $bootstrapColWidth; ?>">
            <li><?php echo $row['freature'] ?></li>
        </div>
<?php
    $rowCount++;
    if($rowCount % $numOfCols == 0) echo '</div><div class="row">';
}
?>
</div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>

        

        
      </div>
    </section>
    <script>
    var prices         = [];
    prices['3h100km']  = <?php echo $mietemich[0]['3h100km'] ?>;
    prices['3h200km']  = <?php echo $mietemich[0]['3h200km'] ?>;
    prices['3h300km']  = <?php echo $mietemich[0]['3h300km'] ?>;
    prices['3h400km']  = <?php echo $mietemich[0]['3h400km'] ?>;
    prices['3h500km']  = <?php echo $mietemich[0]['3h500km'] ?>;
    prices['6h100km']  = <?php echo $mietemich[0]['6h100km'] ?>;
    prices['6h200km']  = <?php echo $mietemich[0]['6h200km'] ?>;
    prices['6h300km']  = <?php echo $mietemich[0]['6h300km'] ?>;
    prices['6h400km']  = <?php echo $mietemich[0]['6h400km'] ?>;
    prices['6h500km']  = <?php echo $mietemich[0]['6h500km'] ?>;
    prices['9h100km']  = <?php echo $mietemich[0]['9h100km'] ?>;
    prices['9h200km']  = <?php echo $mietemich[0]['9h200km'] ?>;
    prices['9h300km']  = <?php echo $mietemich[0]['9h300km'] ?>;
    prices['9h400km']  = <?php echo $mietemich[0]['9h400km'] ?>;
    prices['9h500km']  = <?php echo $mietemich[0]['9h500km'] ?>;
    prices['12h100km'] = <?php echo $mietemich[0]['12h100km'] ?>;
    prices['12h200km'] = <?php echo $mietemich[0]['12h200km'] ?>;
    prices['12h300km'] = <?php echo $mietemich[0]['12h300km'] ?>;
    prices['12h400km'] = <?php echo $mietemich[0]['12h400km'] ?>;
    prices['12h500km'] = <?php echo $mietemich[0]['12h500km'] ?>;
    prices['24h100km'] = <?php echo $mietemich[0]['24h100km'] ?>;
    prices['24h200km'] = <?php echo $mietemich[0]['24h200km'] ?>;
    prices['24h300km'] = <?php echo $mietemich[0]['24h300km'] ?>;
    prices['24h400km'] = <?php echo $mietemich[0]['24h400km'] ?>;
    prices['24h500km'] = <?php echo $mietemich[0]['24h500km'] ?>;
    prices['48h100km'] = <?php echo $mietemich[0]['48h100km'] ?>;
    prices['48h200km'] = <?php echo $mietemich[0]['48h200km'] ?>;
    prices['48h300km'] = <?php echo $mietemich[0]['48h300km'] ?>;
    prices['48h400km'] = <?php echo $mietemich[0]['48h400km'] ?>;
    prices['48h500km'] = <?php echo $mietemich[0]['48h500km'] ?>;
    </script>
    <script src="<?php echo base_url(); ?>assets/front/js/mietemich_single.js"></script>
     
    <!-- Initialize Swiper -->