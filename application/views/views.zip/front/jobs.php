   <style>
   	.number_heading{
   		font-size: 55px;
   		color: #3B3C95;

   	}
   	.heading_2{
   		font-size:22px;line-height:1.9;color:#000;
   	}
    .custom-pera p {
      line-height: 1.5;
    }
    .bordered_col{
      border-bottom: 1px dotted #8E8C8B; 
    }
    .fa-check{
      font-size: 25px;
      color: #8E8C8B;
    }
   </style> 
    <section id="main">
      <div class="container">

        	<div class="row pt-5 pb-4 bg-white mb-5 font-weight-light custom-pera">
            <div class="col-md-12 pt-5 ">
            <h3 class="left-br font-weight-light">Jobs</h3>
            <strong><p class="ml-3 mt-5">Zurzeit ist unser Team komplett.
​</p></strong>
            </div>

           

        		
              
            </div>

        	</div>
        </div>
    </div>
  </div>
</section>