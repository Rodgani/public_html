<style>body{ background-color: #fff !important; }</style>
    
    <section id="main">
      <div class="container py-5">
        <div class="row">
          
          <div class="col-lg-3 col-md-4">

              <form class="auto_submit_item" method="get" action="<?php echo base_url();?>miete-mich-taeglich">
            <h6 class="mb-2">Konfiguriere dein Abo</h6>
            <ul class="list-group">
              <li class="list-group-item border-0 p-0 pb-3 mb-1">
                <fieldset>
                  <legend class="small mb-0 text-muted">Kilometer pro tag:</legend>
                  <div class="form-group mb-2">
                    <select class="form-control border-0 px-2" id="km" name="km">
                      <option <?php echo ($km == '100km') ? 'selected' : ''; ?> value="100km">100 km</option>
                      <option <?php echo ($km == '200km') ? 'selected' : ''; ?> value="200km">200 km</option>
                      <option <?php echo ($km == '300km') ? 'selected' : ''; ?> value="300km">300 km</option>
                      <option <?php echo ($km == '400km') ? 'selected' : ''; ?> value="400km">400 km</option>
                      <option <?php echo ($km == '500km') ? 'selected' : ''; ?> value="500km">500 km</option>
                      
                    </select>
                  </div>
                </fieldset>    
                
              </li>
<?php /* ?>
              <li class="list-group-item border-0 p-0 mb-3">
                <a href="" class="small"><i class="fa fa-exclamation-circle" aria-hidden="true"></i> Mehr Infos zu gefahrenen Kilometern</a>
              </li>
<?php */?>
              <li class="list-group-item border-0 p-0 mb-1">
                <fieldset>
                  <legend class="small mb-0 text-muted">Dauer:</legend>
                  <div class="form-group mb-2">
                    <select class="form-control border-0 px-2" id="duration" name="duration">
                      <option <?php echo ($duration == '3h') ? 'selected' : ''; ?> value="3h">3 Stunden</option>
                      <option <?php echo ($duration == '6h') ? 'selected' : ''; ?> value="6h">6 Stunden</option>
                      <option <?php echo ($duration == '9h') ? 'selected' : ''; ?> value="9h">9 Stunden</option>
                      <option <?php echo ($duration == '12h') ? 'selected' : ''; ?> value="12h">12 Stunden</option>
                      <option <?php echo ($duration == '24h') ? 'selected' : ''; ?> value="24h">24 Stunden</option>
                      <option <?php echo ($duration == '48h') ? 'selected' : ''; ?> value="48h">48 Stunden</option>
                    </select>
                  </div>
                </fieldset>    
              </li>

              <li class="list-group-item border-0 p-0 mb-3">
                <span class="small"><i class="fa fa-check text-success" aria-hidden="true"></i> Im Anschluss monatlich kündbar</span>
              </li>
            
            </ul>

            <h6 class="mt-4 mb-2">Getriebe</h6>
            <ul class="list-group">
              <li class="list-group-item border-0 p-0">
                <input type="radio"  value="all" name="transmission" aria-label="Radio button for following text input" id="alle" <?php echo ($transmission == 'all') ? 'checked' :''; ?>> &nbsp;  <label class="mb-0" for="alle">Alle</label>     
              </li>

              <li class="list-group-item border-0 p-0">
                <input type="radio"  name="transmission" value="automatisch" aria-label="Radio button for following text input" id="automat" <?php echo ($transmission == 'automatisch') ? 'checked' :''; ?>> &nbsp;  <label class="mb-0" for="automat"> Automat </label>     
              </li>

              <li class="list-group-item border-0 p-0">
                <input type="radio" value="menual" name="transmission" aria-label="Radio button for following text input" id="manuell"  <?php echo ($transmission == 'menual') ? 'checked' :''; ?>> &nbsp;  <label class="mb-0" for="manuell"> Manuell </label>     
              </li>
            </ul>

            <h6 class="mt-4 mb-2">Treibstoff</h6>
            <ul class="list-group">
              <li class="list-group-item border-0 p-0">
                <input type="radio" name="fuel" aria-label="Radio button for following text input" id="alleTwo" value="all" <?php echo ($fuel == 'all') ? 'checked' :''; ?>> &nbsp;  <label class="mb-0" for="alleTwo">Alle</label>     
              </li>

              <li class="list-group-item border-0 p-0">
                <input type="radio" value="gasoline" name="fuel" aria-label="Radio button for following text input" id="benzin" <?php echo ($fuel == 'gasoline') ? 'checked' :''; ?>> &nbsp;  <label class="mb-0" for="benzin"> Benzin </label>     
              </li>

              <li class="list-group-item border-0 p-0">
                <input type="radio" value="diesel" name="fuel" aria-label="Radio button for following text input" id="diesel" <?php echo ($fuel == 'diesel') ? 'checked' :''; ?>> &nbsp;  <label class="mb-0" for="diesel"> Diesel </label>     
              </li> 

              <li class="list-group-item border-0 p-0">
                <input type="radio" value="electro" name="fuel" aria-label="Radio button for following text input" id="elektro" <?php echo ($fuel == 'electro') ? 'checked' :''; ?>> &nbsp;  <label class="mb-0" for="elektro"> Elektro </label>     
              </li>
              <li class="list-group-item border-0 p-0">
                <input type="radio" value="hybrid" name="fuel" aria-label="Radio button for following text input" id="hybrid" <?php echo ($fuel == 'hybrid') ? 'checked' :''; ?>> &nbsp;  <label class="mb-0" for="hybrid"> Hybrid </label>     
              </li>

            </ul>

              </form>

            <h4 class="mt-4"><b>Im Preis enthalten</b></h4>
           <?php /* ?> <p class="text-primary font-weight-bold mb-0"><i class="fa fa-car " aria-hidden="true"></i> Our-Service</p> <?php */ ?>
            <div class="accordion" id="accordionExample">
              <div class="card border-top-0 border-left-0 border-right-0 border-bottom rounded-0">
                <div class="card-header p-0 bg-white" id="headingOne">
                  <h2 class="mb-0">
                    <button class="btn btn-link pl-0 w-100 text-left text-dark" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                      <i class="fa fa-check text-success" aria-hidden="true"></i> &nbsp;Dein Auto inkl. Kilometer
                    </button>
                  </h2>
                </div>

                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div class="card-body small p-2">
                    Natürlich dein neues Auto und die gewählten Kilometer. Das Auto kommt entweder direkt von unserem Lager oder kommt frabrikneu ab Werk.
                  </div>
                </div>
              </div>

              <div class="card border-top-0 border-left-0 border-right-0 border-bottom rounded-0">
                <div class="card-header p-0 bg-white" id="headingTwo">
                  <h2 class="mb-0">
                    <button class="btn btn-link pl-0 w-100 text-left text-dark" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                      <i class="fa fa-check text-success" aria-hidden="true"></i> &nbsp;Versicherung
                    </button>
                  </h2>
                </div>

                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                  <div class="card-body small p-2">
                   Im Our-Service sind sowohl Haftpflichtversicherung als auch Vollkaskoversicherung eingeschlossen. Bei Haftpflicht- und Teilkaskoschäden gibt es keinen Selbstbehalt. Den Selbstbehalt für Vollkaskoschäden kannst du zwischen 500–1500 CHF selber bestimmen.
                  </div>
                </div>
              </div>

              <div class="card border-top-0 border-left-0 border-right-0 border-bottom rounded-0">
                <div class="card-header p-0 bg-white" id="headingThree">
                  <h2 class="mb-0">
                    <button class="btn btn-link pl-0 w-100 text-left text-dark" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                      <i class="fa fa-check text-success" aria-hidden="true"></i> &nbsp;Zulassung
                    </button>
                  </h2>
                </div>

                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                  <div class="card-body small p-2">
                   Das Auto wird in deinem Wohnkanton eingelöst. Die Nummernschilder und den Fahrzeugausweis organisieren wir für dich. 
                  </div>
                </div>
              </div>

              <div class="card border-top-0 border-left-0 border-right-0 border-bottom rounded-0">
                <div class="card-header p-0 bg-white" id="headingFour">
                  <h2 class="mb-0">
                    <button class="btn btn-link pl-0 w-100 text-left text-dark" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                      <i class="fa fa-check text-success" aria-hidden="true"></i> &nbsp;Steuern 
                    </button>
                  </h2>
                </div>

                <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                  <div class="card-body small p-2">Auch die Steuern sind im Our-Service bereits abgedeckt. Du brauchst dir um die Fahrzeugsteuern keine Gedanken zu machen.</div>
                </div>
              </div>


              <div class="card border-top-0 border-left-0 border-right-0 border-bottom rounded-0">
                <div class="card-header p-0 bg-white" id="headingFive">
                  <h2 class="mb-0">
                    <button class="btn btn-link pl-0 w-100 text-left text-dark" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                      <i class="fa fa-check text-success" aria-hidden="true"></i> &nbsp;Service und Wartung 
                    </button>
                  </h2>
                </div>

                <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
                  <div class="card-body small p-2">Jegliche Service- und Wartungsarbeiten sind in unserem Service inbegriffen. Wir übernehmen nicht nur den Papierkram, sondern koordinieren auf Wunsch auch gerne Termine bei einer Partnergarage in deiner Nähe.</div>
                </div>
              </div>


              <div class="card border-top-0 border-left-0 border-right-0 border-bottom rounded-0">
                <div class="card-header p-0 bg-white" id="headingSix">
                  <h2 class="mb-0">
                    <button class="btn btn-link pl-0 w-100 text-left text-dark" type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                      <i class="fa fa-check text-success" aria-hidden="true"></i> &nbsp;Bereifung 
                    </button>
                  </h2>
                </div>

                <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionExample">
                  <div class="card-body small p-2">Wir stellen die Richtigen Bereifung sicher. Teil davon sind die Reifen selber, deren Lagerung und allfällige Wechsel. Damit du die Reifen bequem bei einer Garage in deiner Nähe wechseln kannst, stellen wir sicher, dass deine Reifen dort bereit stehen. </div>
                </div>
              </div>

              <div class="card border-top-0 border-left-0 border-right-0 border-bottom rounded-0">
                <div class="card-header p-0 bg-white" id="headingSeven">
                  <h2 class="mb-0">
                    <button class="btn btn-link pl-0 w-100 text-left text-dark" type="button" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                      <i class="fa fa-check text-success" aria-hidden="true"></i> &nbsp;Erstvignette
                    </button>
                  </h2>
                </div>

                <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordionExample">
                  <div class="card-body small p-2">Dein Auto hat alles, was es für die Schweizer Strasse braucht, so auch die Autobahnvignette. Ins Ausland darfst du natürlich auch, bitte beachte da allfällige Gebühren auf Autobahnen.</div>
                </div>
              </div>


              <div class="card border-top-0 border-left-0 border-right-0 border-bottom rounded-0">
                <div class="card-header p-0 bg-white" id="headingEight">
                  <h2 class="mb-0">
                    <button class="btn btn-link pl-0 w-100 text-left text-dark" type="button" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                      <i class="fa fa-check text-success" aria-hidden="true"></i> &nbsp;Tankkarte 
                    </button>
                  </h2>
                </div>

                <div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-parent="#accordionExample">
                  <div class="card-body small p-2">Zu deinem Auto erhältst du eine persönliche Tankkarte. Damit profitierst du von 5 Rp. Rabatt pro Liter. Dies gilt bei allen 600 AVIA Tankstellen in der Schweiz.</div>
                </div>
              </div>
            </div>

          </div>
          <div class="col-lg-9 col-md-8">
            <div class="row">
              <?php 
                 $querystring = http_build_query($config);
               ?>

<?php foreach ($mietemichs as $key => $mietemich): ?>
                      <?php
                        $images = explode(',', $mietemich['images']);
                       $image  = $images[0];  
                       ?>

                <div class="col-lg-6 col-md-6 mb-4">
                <a href="<?php echo base_url() ?>miete-mich-taeglich/<?php echo $mietemich['slug']?>?<?php echo trim($querystring) ?>" class="card rounded-0 text-dark">
                    <img class="card-img-top mt-4" src="<?php echo base_url(); ?>uploads/mietemich/<?php echo $image ?>" alt="Image">
                    <div class="card-body">
                      <h6 style="text-transform: capitalize;" class="mb-0"><?php echo $mietemich['vehicle_brand'] ?></h6>
                      <h5 style="text-transform: capitalize;" class="card-title mb-1"><?php echo $mietemich['vehicle_name'] ?></h5>
                      <p class="card-text mb-0">ab <strong class="text-primary"><?php echo $mietemich[$select_price]; ?> CHF</strong></p>
                      <small class="text-muted"> <?php echo $km ?> •  <?php echo str_replace('h',' Stunden', $duration);  ?> </small>
                    </div>
                    <?php if ($mietemich['one_car_left']) {?>
                      <span class="badge badge-light position-absolute p-2 rounded-0"> nur noch <b> 1 Stk. </b>  verfügbar </span>
                    <?php } ?>

                    <?php if ($mietemich['summer_special']) { ?>
                      <span class="badge badge-danger position-absolute p-2 right rounded-0">Sommeraktion</span>
                    <?php } else if ($mietemich['winter_special']) {?>
                      <span class="badge badge-danger position-absolute p-2 right rounded-0">Winteraktion</span>
                    <?php } else if ($mietemich['brand_new']) {?>
                      <span class="badge badge-primary position-absolute p-2 right rounded-0">Brandneu</span>
                    <?php } else if ($mietemich['hybrid']) {?>
                      <span class="badge badge-primary position-absolute p-2 right rounded-0">Hybrid</span>
                    <?php } ?>
                </a>
              </div>
<?php endforeach ?>


            </div>
          </div>

        </div>
      </div>
    </section>
